package com.JiuYi.video;

import android.Manifest;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler; // 新增：导入Handler（解决"未知实体'Handler'"错误）
import android.os.Vibrator;
import android.widget.Toast;
import com.JiuYi.video.R;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.hardware.Camera;
import android.hardware.Camera.Parameters;

public class MainActivity extends AppCompatActivity {

    // 1. 震动相关
    private Vibrator vibrator;
    private boolean isVibrating = false;

    // 2. 闪光灯相关
    private Camera camera;
    private Parameters cameraParams;
    private boolean isFlashOn = false;

    // 3. 音量控制相关
    private AudioManager audioManager;
    private int maxMediaVolume;
    private Handler volumeHandler; // 新增：声明Handler（用于停止循环）
    private Runnable volumeRunnable; // 新增：声明Runnable（用于停止循环）

    // 4. 音频播放相关
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化功能（顺序不可乱）
        requestPermissions(); // 1. 申请相机权限
        initVibrate();        // 2. 启动持续震动
        initFlashlight();     // 3. 启动闪光灯常亮
        initVolumeControl();  // 4. 循环保持音量最大（核心修改）
        initAudioPlayer();    // 5. 循环播放音频
    }

    // ------------------------------ 1. 持续震动功能 ------------------------------
    private void initVibrate() {
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) {
            Toast.makeText(this, "设备不支持震动", Toast.LENGTH_SHORT).show();
            return;
        }
        long[] pattern = new long[]{0, 1000}; // 0ms延迟，震动1000ms
        vibrator.vibrate(pattern, -1); // -1表示无限循环
        isVibrating = true;
    }

    // ------------------------------ 2. 闪光灯常亮功能 ------------------------------
    private void initFlashlight() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "需要相机权限才能开启闪光灯", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            camera = Camera.open();
            cameraParams = camera.getParameters();
            cameraParams.setFlashMode(Parameters.FLASH_MODE_TORCH); // 手电筒模式（常亮）
            camera.setParameters(cameraParams);
            camera.startPreview(); // 必须启动预览（否则闪光灯不亮）
            isFlashOn = true;
        } catch (Exception e) {
            Toast.makeText(this, "闪光灯开启失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    // ------------------------------ 3. 音量保持最大功能（循环版，解决所有音量错误） ------------------------------
    private void initVolumeControl() {
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audioManager == null) return;

        // 1. 获取媒体流最大音量（仅执行一次）
        maxMediaVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

        // 2. 使用Handler循环设置音量（每隔1秒）
        volumeHandler = new Handler(); // 初始化Handler（解决"未知变量类型'handler'"错误）
        volumeRunnable = new Runnable() {
            @Override
            public void run() {
                // 强制设置音量为最大（每次循环执行）
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxMediaVolume, 0); // 0表示无动画
                // 1秒后再次执行（循环）
                volumeHandler.postDelayed(this, 1000); // 1000ms = 1秒
            }
        };

        // 启动循环（Activity创建时执行）
        volumeHandler.post(volumeRunnable);
    }

    // ------------------------------ 4. 循环播放音频功能 ------------------------------
    private void initAudioPlayer() {
        try {
            mediaPlayer = MediaPlayer.create(this, R.raw.a); // 加载res/raw/a.mp3（必须命名正确）
            mediaPlayer.setLooping(true); // 循环播放
            mediaPlayer.start(); // 启动播放
        } catch (Exception e) {
            Toast.makeText(this, "音频播放失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    // ------------------------------ 5. 动态权限申请（必须） ------------------------------
    private void requestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 100); // 申请相机权限
        }
    }

    // ------------------------------ 6. 权限申请结果回调 ------------------------------
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            initFlashlight(); // 权限通过后开启闪光灯
        } else {
            Toast.makeText(this, "拒绝相机权限将无法开启闪光灯", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------ 7. 资源释放（防止内存泄漏） ------------------------------
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 停止震动
        if (isVibrating) vibrator.cancel();
        // 释放闪光灯资源
        if (isFlashOn) {
            camera.stopPreview();
            camera.release();
        }
        // 停止音频播放
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
        // 停止音量循环（核心：解决Handler内存泄漏）
        if (volumeHandler != null && volumeRunnable != null) {
            volumeHandler.removeCallbacks(volumeRunnable); // 移除循环任务
        }
    }
}
